var entry = []

/**
 * Checks if a string is a palindrome
 * @param {string} str the string that is entered, essentially is going to be the word given by the user
 * @returns {boolean} true or false
 */
function palindrome(str) {
    var re = /[\W_]/g;
    var lowRegStr = str.toLowerCase().replace(re, '');
    var reverseStr = lowRegStr.split('').reverse().join(''); 
    return reverseStr === lowRegStr;
  }

  /**
   * Takes on the point value of an object, sorts it inorder 
   * then reverses the strings by displaying the highest. 
   * Lastly, we select the first 5 to display the top score
   * @param {array} array 
   */
function findTopScores(array) {
    return array.sort(function(a,b){return a.points - b.points}).reverse().slice(0, 1) 
}


class GameController{
    getAllScores(req, res) {
        let score = findTopScores(entry)
        return res.status(200).send({
            success: 'true',
            entry
        });
    }

    submitEntry(req, res) {
        if(!req.body.name){
            return res.status(400).send({
                success: 'false',
                message: 'name is required'
            });
        } else if (!req.body.word){
                return res.status(400).send({
                    success: 'false',
                    message: 'word is required'
                });
        }
        var newEntry = {
            name: req.body.name,
            word: req.body.word,
            points: req.body.word.length
        }
        if (palindrome(req.body.word) === true) {
            entry.push(newEntry);
        return res.status(201).send({
            success: 'true',
            message: "entry added",
            newEntry
        });
        } else {
            return res.status(400).send({
                success: 'false',
                message: 'not valid plaindrome'
            });
        }
        
    }
}

var gameController = new GameController();
module.exports = gameController;