var express = require('express');
var router = require('./routes/index.js');
var bodyParser = require('body-parser');



var app = express();

app.use(express.static(__dirname));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false}));
app.use(router);

app.get('/', function(req, res) {
	res.render('index.html');
});

var port = 3000;
app.listen(port, function() {
	console.log('Server', process.pid, 'listening on port', port);
});

/**
 *
 * 1. Define my endpoints. return dummy text. 
 * 	a. GET /getScores
 * 	b. POST /submitEntry
 * 2. Implement submitEntry to accept {name: "", word: ""}
 * 	a. Implement the function to accept the word - check if its a palindrome and return the score.
 *  b. Implement the function to accept the word and the name, and add it to the score list.
 * 3. Implement getScores
 *  a. return all the scores in the format: [{"name": "", "points":"" }]	
 */
