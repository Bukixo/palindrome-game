var express = require('express');
var GameController = require('../controllers/game.js')
var router = express.Router();


router.get('/api/getScores', GameController.getAllScores);
router.post('/api/submitEntry', GameController.submitEntry);

module.exports = router